#!/usr/bin/python3

from scipy.signal import TransferFunction
from matplotlib import pyplot

R = 220
L = 220*10**-6
C = 1*10**-9

h = TransferFunction([1/(L*C)], [1, R/L, 1/(L*C)])

t, v = h.step()

pyplot.plot(t, v)
pyplot.show()
